from distutils.core  import setup

setup(
    name='projectname',
    version='1.0',
    author='Abel',
    author_email='greatabel1@126.com',
    url='https://github.com/greatabel/PythonRepository',
    packages=['projectname','projectname.utils']
    )