# Sharingan

[Flask](http://flask.pocoo.org/) based API server for clairvoyant and byakugan.

![sharingan](http://vignette3.wikia.nocookie.net/naruto/images/5/56/Sharingan_Triple.svg/revision/latest/scale-to-width-down/128)

## Prerequisite

### Python 3.4

Install with pyenv

```
brew install pyenv
pyenv install 3.4.4
```

### venv

Use plugin for pyenv to manage virutalenv

```
brew install pyenv-virtualenv
pyenv virtualenv 3.4.4 sharingan
```

Add startup script to `~/.bash_profile`

```
eval "$(pyenv init -)"
eval "$(pyenv virtualenv-init -)"
```

### python packages

```
pyenv activate sharingan
cd path/to/your/project
pip install -r requirements.txt
```

### mysql

```
brew install mysql
mysql.server start
mysql -u root

CREATE DATABASE sharingan;
GRANT ALL ON sharingan.* TO 'sharingan'@'localhost' IDENTIFIED BY 'sharingan';
```

## Use flask command line tool

### Set environment variable

```
export FLASK_APP=/path/to/your/app
```

### upgrade database schema

```
pyenv activate sharingan
cd path/to/your/project
flask db upgrade
```

### generated migration script

```
flask db migrate -m <title>
```

Then edit `migrations/versions/` and commit.

### Run a local server

```
flask run
```

## Happy hacking!
