import pytest


@pytest.fixture(scope='module')
def testdb(request, app):
    '''
    Create tables before each module(python file) and drop them after.
    '''
    from sharingan import db, app
    context = app.app_context()
    context.push()
    db.create_all()

    def teardown():
        db.session.remove()
        db.drop_all()
        context.pop()

    request.addfinalizer(teardown)

    return db


@pytest.fixture(scope='session')
def app():
    from sharingan import hookup_app, app

    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite://'  # use memory db
    app.testing = True
    hookup_app(app)

    return app
