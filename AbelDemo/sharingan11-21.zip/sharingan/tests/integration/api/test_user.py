import json
from collections import namedtuple

import pytest

from sharingan.models import User


@pytest.fixture(scope='module', autouse=True)
def data(testdb):
    user = User(name='mock user')
    testdb.session.add(user)
    testdb.session.commit()
    return namedtuple('Data', 'user')(user)


@pytest.fixture(scope='module')
def app_client(app):
    return app.test_client()


def test_user(app_client, data):
    response = app_client.get('/' + str(data.user.id))
    assert response.status_code == 200
    assert json.loads(response.data.decode('utf-8')) == {'name': 'mock user'}
