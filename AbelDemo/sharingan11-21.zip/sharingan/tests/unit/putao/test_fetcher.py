from sharingan.api import api  # NOQA: sample import


def test_dummy():
    pass
