from os import environ
from flask_migrate import Migrate
from flask_script import Manager

from sharingan import hookup_app, app, db
# all declared models to be included in db migration
import sharingan.models  # NOQA


def _config(app):
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://{user}:{pwd}@{host}/{database}'.format(
        user=environ.get('DB_USER', 'sharingan'),
        pwd=environ.get('MYSQLCONNSTR_DB_PWD', 'sharingan'),
        host=environ.get('DB_HOST', 'localhost'),
        database=environ.get('DB_NAME', 'sharingan')
    )
    app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True

_config(app)
hookup_app(app)

manager = Manager(app)
migrate = Migrate(app, db)

if __name__ == '__main__':
    manager.run()
