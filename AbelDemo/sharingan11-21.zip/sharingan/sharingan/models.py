from . import db

patient_user = db.Table('patient_users', db.Model.metadata,
                        db.Column('patient_id', db.Integer, db.ForeignKey('patients.id')),
                        db.Column('user_id', db.Integer, db.ForeignKey('users.id')))


class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    # sex column value: 0 means male, 1 means female
    sex = db.Column(db.Boolean, unique=False, default=False)
    birthday = db.Column(db.Date)
    mobilephone = db.Column(db.String(20))
    email = db.Column(db.String(20))
    picture = db.Column(db.LargeBinary)
    created_date = db.Column(db.DateTime)
    patients = db.relationship("Patient", secondary=patient_user)


class UserInfo(db.Model):
    __tablename__ = 'userinfos'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    oauth_id = db.Column(db.String(100))
    # sex column value: 0 means male, 1 means female
    sex = db.Column(db.Boolean, unique=False, default=False)
    birthday = db.Column(db.Date)
    picture = db.Column(db.LargeBinary)
    email = db.Column(db.String(20))
    origin = db.Column(db.String(20))
    created_date = db.Column(db.DateTime)
    last_modified_date = db.Column(db.DateTime)


class Measure(db.Model):
    __tablename__ = 'measures'
    id = db.Column(db.Integer, primary_key=True)
    rawdata = db.relationship("MeasureRaw")
    data = db.Column(db.String(100))
    deviceid = db.Column(db.String(100))
    created_date = db.Column(db.DateTime)


class MeasureRaw(db.Model):
    __tablename__ = 'measureraws'
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.Binary)
    measure_id = db.Column(db.Integer, db.ForeignKey('measures.id'))
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'))
    right_eye = db.Column(db.Boolean, unique=False, default=False)
    created_date = db.Column(db.DateTime)


class Patient(db.Model):
    __tablename__ = 'patients'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    sex = db.Column(db.Boolean, unique=False, default=False)
    birthday = db.Column(db.Date)
    picture = db.Column(db.LargeBinary)
    created_date = db.Column(db.DateTime)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    last_modified_date = db.Column(db.DateTime)
    last_modified_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    rawdata = db.relationship('MeasureRaw')


class MeasureBaseline(db.Model):
    __tablename__ = 'measurebaseline'
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'))
    data = db.Column(db.String(100))
    right_eye = db.Column(db.Boolean, unique=False, default=False)
    created_date = db.Column(db.DateTime)
