from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
db = SQLAlchemy()


def hookup_app(app):
    db.init_app(app)

    from .api import blueprint
    app.register_blueprint(blueprint)

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
