from flask import Blueprint
from flask_restful import Api
from flask_restful import reqparse


blueprint = Blueprint('api', __name__)
api = Api(blueprint)

measurement_parser = reqparse.RequestParser()
measurement_parser.add_argument('rawdata')
measurement_parser.add_argument('righteye')

sightcalc_parser = reqparse.RequestParser()
sightcalc_parser.add_argument('step')
sightcalc_parser.add_argument('ppi')

# end point definitions
from . import user  # NOQA
from . import patient  # NOQA
from . import sightcalculator # NOQA
