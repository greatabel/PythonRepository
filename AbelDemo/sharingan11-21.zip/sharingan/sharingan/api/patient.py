from flask_restful import abort, Resource
from flask import send_file

from . import api, blueprint, measurement_parser
from .. import models
from .. import db
import datetime
from base64 import b64encode
import io


@blueprint.route('/patients/<patient_id>/avatar')
def patientavatar(patient_id):
    patient = models.Patient.query.filter_by(id=patient_id).first()
    if patient is None or patient.picture is None:
        abort(404, message="patient {} 's avatar doesn't exist".format(patient_id))
    else:
        base64_bytes = b64encode(patient.picture)
        return send_file(io.BytesIO(base64_bytes), attachment_filename='avatar.png',
                         mimetype='image/png')


class PatientMeasurements(Resource):
    def get(self, patient_id):
        # raw = models.MeasureRaw.query.filter_by(patient_id=patient_id).all()
        # print(raw[0].data)
        raws = models.Patient.query.filter_by(id=patient_id).first().rawdata
        if raws is None:
            abort(404, message="patient {} 's measure data doesn't exist".format(patient_id))
        # print('#'*10, raws[0].data)
        res = [
            {
                'rawdata': obj.data.decode('utf-8'),
                'righteye': obj.right_eye,
                'createddate': str(obj.created_date)
            } for obj in raws
        ]
        return res

    def post(self, patient_id):
        args = measurement_parser.parse_args()
        print(args)
        if args["rawdata"] is not None and args['righteye'] is not None\
           and args['righteye'] in ('0', '1') and args["rawdata"].isdigit():
            # DB.add_rawmeasure(args)
            measureraw = models.MeasureRaw(data=args["rawdata"].encode('utf-8'),
                                           right_eye=args['righteye'],
                                           patient_id=patient_id,
                                           created_date=datetime.datetime.now())
            db.session.add(measureraw)
            db.session.flush()
            db.session.commit()
        else:
            abort(403, message="measurement's some parameter is emtpy or not correct")
        return {'id': measureraw.id}, 201


api.add_resource(PatientMeasurements, '/patients/<patient_id>/measurements')
