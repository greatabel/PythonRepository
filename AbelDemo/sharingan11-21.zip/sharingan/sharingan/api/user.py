from flask_restful import abort, Resource

from . import api
from .. import models


class User(Resource):
    # TODO: remove unnecessary id in api-url
    def get(self, user_id):
        user = models.User.query.get(user_id)
        if user is None:
            abort(404, message="user {} 's data  doesn't exist".format(user_id))
        return {'name': user.name}


class PatientCollection(Resource):
    def get(self, user_id):
        patients = models.User.query.filter_by(id=user_id).first().patients
        if patients is None:
            abort(404, message="user {} 's data doesn't exist".format(user_id))
        res = [
            {
                'patientid': obj.id,
                'name': obj.name,
                'sex': obj.sex,
                'birthday': str(obj.birthday),
                'created_date': str(obj.created_date)
            } for obj in patients
        ]
        return res


# class Patient(Resource):
#     def get(self, user_id, patient_id):
#         return user_id + '#' + patient_id


api.add_resource(User, '/<user_id>')
api.add_resource(PatientCollection, '/<user_id>/patients')
# api.add_resource(Patient, '/<user_id>/patients/<patient_id>')
# api.add_resource(PatientAvater, '/<user_id>/patientavatar/<patient_id>')
