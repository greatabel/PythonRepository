from flask_restful import abort, Resource

from . import api, sightcalc_parser
import math


def isfloat(value):
    try:
        float(value)
        return True
    except ValueError:
        return False


class SightCalculator(Resource):
    def get(self):
        args = sightcalc_parser.parse_args()
        if args['step'] is None or args['ppi'] is None:
            return abort(404, message="CalculateMeasure have empty parameter")
        if not args['step'].isdigit() or not isfloat(args['ppi']):
            return abort(404, message="CalculateMeasure have error parameter")
        step = int(args['step'])
        ppi = float(args['ppi'])
        # print('test')
        return_value = 165 + 25 * step * 461 / ppi
        floating_pointpart = (return_value / 25) % 1
        integer_part = math.floor(return_value / 25)
        if floating_pointpart >= 0.5:
            integer_part += 1
        return_value = 25 * integer_part
        raw_data = {'result': return_value}
        return raw_data


api.add_resource(SightCalculator, '/sightcalculator')
